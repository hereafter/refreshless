var RefreshItem = (function () {
    function RefreshItem() {
    }
    return RefreshItem;
}());
