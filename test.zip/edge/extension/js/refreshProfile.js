var RefreshProfile = (function () {
    function RefreshProfile() {
    }
    RefreshProfile.prototype.RefreshProfile = function () {
        this.url = "";
        this.interval = 5;
        this.enabled = true;
        this.saved = false;
    };
    return RefreshProfile;
}());
