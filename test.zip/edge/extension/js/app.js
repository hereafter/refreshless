var App = (function () {
    function App() {
    }
    Object.defineProperty(App, "theme", {
        get: function () {
            var item = localStorage.getItem("theme");
            if (item == null)
                return "light";
            return item;
        },
        set: function (v) {
            localStorage.setItem("theme", v);
        },
        enumerable: true,
        configurable: true
    });
    return App;
}());
