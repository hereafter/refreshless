var RefreshProfile = (function () {
    function RefreshProfile() {
        this.url = "";
        this.interval = 5;
        this.enabled = false;
    }
    return RefreshProfile;
}());
var TabRefreshProfile = (function () {
    function TabRefreshProfile() {
        this.saved = true;
        this.profile = new RefreshProfile();
    }
    return TabRefreshProfile;
}());
