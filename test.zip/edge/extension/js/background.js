var Service = (function () {
    function Service() {
    }
    Service.getTabProfile = function (tab) {
        return this.getTabProfile2(tab.id, tab.url);
    };
    Service.getTabProfile2 = function (tabId, url) {
        var pos = url.indexOf('?');
        if (pos > 0) {
            url = url.substr(0, pos);
        }
        if (this.tabProfiles.has(tabId)) {
            var p = this.tabProfiles.get(tabId);
            if (p.profile.url == url)
                return p;
        }
        var tp = new TabRefreshProfile();
        tp.profile.url = url;
        this.tabProfiles.set(tabId, tp);
        if (this.profiles.has(url)) {
            var p2 = this.profiles.get(url);
            tp.profile.url = url;
            tp.profile.enabled = p2.enabled;
            tp.profile.interval = p2.interval;
            tp.saved = true;
        }
        return tp;
    };
    Service.resetProfiles = function () {
        this.profiles.clear();
        localStorage.removeItem("profiles");
    };
    Service.loadProfiles = function () {
        this.profiles.clear();
        var item = localStorage.getItem("profiles");
        if (item == null)
            return;
        try {
            var tmp = JSON.parse(item);
            for (var _i = 0, tmp_1 = tmp; _i < tmp_1.length; _i++) {
                var t = tmp_1[_i];
                this.profiles.set(t.url, t);
            }
        }
        catch (_a) {
            this.profiles.clear();
        }
    };
    Service.saveProfiles = function () {
        var tmp = new Array();
        this.profiles.forEach(function (value, url, map) {
            if (value.enabled) {
                tmp.push(value);
            }
        });
        var item = JSON.stringify(tmp);
        localStorage.setItem("profiles", item);
    };
    Service.initialize = function () {
        this.loadProfiles();
        this.runMessageHandlers();
        this.runTabsHandlers();
    };
    Service.runMessageHandlers = function () {
        var _this = this;
        browser.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            if (request.message == 'get-options') {
                var tab = sender.tab;
                var url = sender.url;
                var o = { tabId: tab.id };
                if (tab != null) {
                    var tp = _this.getTabProfile2(tab.id, url);
                    var profile = tp.profile;
                    o.profile = tp;
                }
                browser.tabs.get(tab.id, function (tt) {
                    if (tt.active) {
                        _this.updateTab(tab.id, tp.profile.enabled);
                    }
                });
                sendResponse(o);
            }
            else if (request.message == 'get-profile') {
                browser.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    var tab = tabs[0];
                    var url = tab.url;
                    var profile = _this.getTabProfile(tab);
                    var o = { 'profile': profile, "tab": tab };
                    sendResponse(o);
                });
            }
            else if (request.message == "set-profile") {
                var tabProfile = request.profile;
                var tab = request.tab;
                var tp = _this.tabProfiles.get(tab.id);
                if (tp != null) {
                    tp.profile.enabled = tabProfile.profile.enabled;
                    tp.profile.interval = tabProfile.profile.interval;
                }
                if (tabProfile.saved) {
                    var url = tabProfile.profile.url;
                    var p = _this.profiles.get(url);
                    if (p == null) {
                        p = new RefreshProfile();
                        p.url = url;
                        _this.profiles.set(url, p);
                    }
                    p.enabled = tabProfile.profile.enabled;
                    p.interval = tabProfile.profile.interval;
                    _this.saveProfiles();
                    browser.tabs.get(tab.id, function (tt) {
                        if (tt.active) {
                            _this.updateTab(tab.id, tp.profile.enabled);
                        }
                    });
                }
                sendResponse({});
            }
            else if (request.message == "has-popup") {
                var popups = browser.extension.getViews({ type: 'popup' });
                var hasPopup = popups.length != 0;
                var o = { 'message': hasPopup };
                sendResponse(o);
            }
            else if (request.message == 'refresh-tick') {
                var tick = request.tick;
                var tabId = request.tabId;
                var text = '';
                if (tick >= 0)
                    text = tick.toString();
                try {
                    browser.browserAction.setBadgeText({
                        text: text, tabId: tabId
                    });
                }
                catch (_a) { }
                sendResponse({});
            }
            return true;
        });
    };
    Service.runTabsHandlers = function () {
        var _this = this;
        browser.tabs.onActivated.addListener(function (info) {
            var tabId = info.tabId;
            var windowId = info.windowId;
            if (tabId == null)
                return;
            var tp = _this.tabProfiles.get(tabId);
            _this.updateTab(tabId, tp != null && tp.profile.enabled);
        });
    };
    Service.updateTab = function (tabId, status) {
        if (status) {
            browser.browserAction.setIcon({ path: {
                    20: "images/status/logo-on-d-20.png",
                    40: "images/status/logo-on-d-40.png"
                }, tabId: tabId });
        }
        else {
            browser.browserAction.setIcon({ path: {
                    20: "images/status/logo-off-d-20.png",
                    40: "images/status/logo-off-d-40.png"
                }, tabId: tabId });
        }
    };
    Service.profiles = new Map();
    Service.tabProfiles = new Map();
    return Service;
}());
Service.initialize();
